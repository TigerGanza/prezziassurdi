# PREZZI ASSURDI

Sito statico gratuito per raccogliere offerte e link Amazon Associates.

## Pubblicazione gratuita con GitHub Pages
1. Crea un account GitHub gratuito.
2. Crea un nuovo repository chiamato `prezziassurdi`.
3. Carica `index.html`.
4. Vai in Settings → Pages.
5. Seleziona il branch `main` e la cartella `/root`.
6. GitHub fornirà l'indirizzo gratuito del sito.

## Prossimo step
Quando il bot Telegram sarà pronto, sostituiremo i prodotti di esempio con i dati reali e potremo creare un flusso automatico:
Amazon/API → database o JSON → sito + Telegram.
